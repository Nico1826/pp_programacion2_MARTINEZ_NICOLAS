package parcialprogramacion2;


public class EvaluacionesFisicas extends Actividades implements GeneraInforme{
    
    private int puntaje;
    
    public EvaluacionesFisicas(String nombre, String entrenadorResponsable, NivelIntensidad nivelIntensidad, int puntaje){
        
        super(nombre, entrenadorResponsable, nivelIntensidad);
        this.puntaje = puntaje;
    }
    
    @Override
    public String generarInforme(){
        return "Informe de evaluacion fisica: " + getNombre()
                + ". Puntaje obtenido: " + puntaje + "/100.";
    }

    @Override
    public String toString() {
        return super.toString() + "EvaluacionesFisicas{ " + "puntaje= " + puntaje + '}';
    }
    
    
}
