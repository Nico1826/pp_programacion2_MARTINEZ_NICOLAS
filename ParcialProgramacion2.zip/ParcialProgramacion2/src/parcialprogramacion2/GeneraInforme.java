package parcialprogramacion2;


public interface GeneraInforme {
    
    String generarInforme();
}
