package parcialprogramacion2;

import java.util.ArrayList;

public class GestionCentroEntrenamiento {
    
    private String nombre;
    private ArrayList<Actividades> actividades;
    
    public GestionCentroEntrenamiento(String nombre) {
        this.nombre = nombre;
        actividades = new ArrayList<>();
    }
    
    public void agregarActividad(Actividades actividad)
        throws ActividadDuplicadaException{
        
        if (actividades.contains(actividad)){
            throw new ActividadDuplicadaException("Ya existe una actividad con nombre '" + 
                    actividad.getNombre() + "' y entrenador '" + actividad.getEntrenador() + "'.");
        }
        actividades.add(actividad);
    }
    
    public ArrayList<Actividades> obtenerActividades(){
        return actividades;
    }
    
    public ArrayList<Actividades> filtrarPorNivel(NivelIntensidad nivel){
        ArrayList<Actividades> filtrado = new ArrayList<>();
        
        for(Actividades a : actividades){
            
            if(a.getIntensidad() == nivel){
                filtrado.add(a);
            }
        }
        
        return filtrado;
    }
    
}
