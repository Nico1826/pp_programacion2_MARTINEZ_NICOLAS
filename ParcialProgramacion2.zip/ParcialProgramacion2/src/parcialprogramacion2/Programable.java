package parcialprogramacion2;


public interface Programable {
    
    void programar();
    
}
