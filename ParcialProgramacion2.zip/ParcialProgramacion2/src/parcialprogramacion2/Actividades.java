package parcialprogramacion2;

import java.util.Objects;

public abstract class Actividades {
    
    private String nombre;
    private String entrenadorResponsable;
    private NivelIntensidad nivelIntensidad;
    
    public Actividades(String nombre, String entrenadorResponsable, NivelIntensidad nivelIntensidad){
        
        this.nombre = nombre;
        this.entrenadorResponsable = entrenadorResponsable;
        this.nivelIntensidad = nivelIntensidad;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getEntrenador(){
        return entrenadorResponsable;
    }
    
    public NivelIntensidad getIntensidad(){
        return nivelIntensidad;
    }
    
    @Override
    public boolean equals(Object o){
        
        if(o == null || !(o instanceof Actividades)){
            return false;
        }
        Actividades a = (Actividades) o;
        return nombre.equals(a.nombre) &&
                entrenadorResponsable.equals(a.entrenadorResponsable);
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + Objects.hashCode(this.nombre);
        hash = 47 * hash + Objects.hashCode(this.entrenadorResponsable);
        return hash;
    }

    @Override
    public String toString() {
        return "Actividades{" + "nombre= " + nombre + ", entrenadorResponsable= " + entrenadorResponsable + ", nivelIntensidad= " + nivelIntensidad + '}';
    }

    
    
    
}
