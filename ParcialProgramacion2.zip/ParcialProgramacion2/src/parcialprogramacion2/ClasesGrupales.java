package parcialprogramacion2;


public class ClasesGrupales extends Actividades implements Programable{
    
    private int cantidadMaxParticipantes;
    
    public ClasesGrupales(String nombre, String entrenadorResponsable, NivelIntensidad nivelIntensidad, int cantidadMaxParticipantes){
        
        super(nombre, entrenadorResponsable, nivelIntensidad);
        this.cantidadMaxParticipantes = cantidadMaxParticipantes;
    }
    
    public void programar(){
        
        System.out.println("Se programo la clase grupal: " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + "ClasesGrupales{ " + "cantidadMaxParticipantes= " + cantidadMaxParticipantes + '}';
    }
    
    
    
    
}
