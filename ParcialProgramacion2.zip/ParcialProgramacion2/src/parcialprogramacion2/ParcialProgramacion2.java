package parcialprogramacion2;

import java.util.ArrayList;

public class ParcialProgramacion2 {


    public static void main(String[] args) {
        
         GestionCentroEntrenamiento centro = new GestionCentroEntrenamiento("Alto Rendimiento Sur"); 
 
        try { 
            centro.agregarActividad( 
                    new ClasesGrupales("Funcional", "Laura Gomez", NivelIntensidad.ALTA, 25) 
            ); 
 
            centro.agregarActividad( 
                    new RutinasPersonalizadas("Plan Fuerza Inicial", "Martin Diaz", 
NivelIntensidad.MEDIA, 8) 
            ); 
 
            centro.agregarActividad( 
                    new EvaluacionesFisicas("Evaluacion Ingreso", "Carla Suarez", 
NivelIntensidad.BAJA, 78) 
            ); 
 
            centro.agregarActividad( 
                    new RutinasPersonalizadas("Plan Resistencia", "Laura Gomez", 
NivelIntensidad.ALTA, 6) 
            ); 
 
            centro.agregarActividad( 
                    new ClasesGrupales("Funcional", "Laura Gomez", NivelIntensidad.MEDIA, 20) 
            ); 
 
        } catch (ActividadDuplicadaException e) { 
            System.out.println("No se pudo agregar la actividad: " + e.getMessage()); 
        } 
 
        System.out.println("Actividades registradas:"); 
        mostrarActividades(centro.obtenerActividades()); 
 
        System.out.println(); 
 
        System.out.println("Actividades programables:"); 
        programarActividades(centro.obtenerActividades()); 
 
        System.out.println(); 
 
        System.out.println("Informes generados:"); 
        generarInformesDesdeMain(centro.obtenerActividades()); 
 
        System.out.println(); 
 
        System.out.println("Actividades de intensidad ALTA:"); 
        mostrarActividades(centro.filtrarPorNivel(NivelIntensidad.ALTA)); 
    } 
    private static void mostrarActividades(ArrayList<Actividades> actividades){
    
    for(Actividades a : actividades){
        System.out.println(a);
    }
}
    private static void programarActividades(ArrayList<Actividades> actividades){
    
    for(Actividades a : actividades){
        
        if(a instanceof Programable){
            
            Programable p = (Programable) a;
            p.programar();
            
        }else{
            
            System.out.println("La actividad '" + a.getNombre()
                    + "' no puede programarse.");
        }
    }
}
    private static void generarInformesDesdeMain(ArrayList<Actividades> actividades){
    
    for(Actividades a : actividades){
        
        if(a instanceof GeneraInforme){
            
            GeneraInforme g = (GeneraInforme) a;
            System.out.println(g.generarInforme());
            
        }else{
            
            System.out.println("La actividad '" + a.getNombre()
                    + "' no genera informe.");
        }
    }
}
    }

    

