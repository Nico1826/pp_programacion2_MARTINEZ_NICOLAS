package parcialprogramacion2;


public enum NivelIntensidad {
    
    BAJA,
    MEDIA,
    ALTA
    
}
