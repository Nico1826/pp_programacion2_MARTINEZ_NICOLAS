package parcialprogramacion2;


public class RutinasPersonalizadas extends Actividades implements Programable, GeneraInforme{
    
    private final int duracionEnSemanas;
    
    public RutinasPersonalizadas(String nombre, String entrenadorResponsable, NivelIntensidad nivelIntensidad, int duracionEnSemanas){
        
        super(nombre, entrenadorResponsable, nivelIntensidad);
        this.duracionEnSemanas = duracionEnSemanas;
    }

    public void programar(){
        
        System.out.println("Se programo la rutina personalizada: " + getNombre());
    }
    
    public String generarInforme(){
        return "Informe de rutina personalizada: " + getNombre() + 
                ". Duracion estimada: " + duracionEnSemanas + " semanas.";
                
    }
    
    @Override
    public String toString() {
        return super.toString() + "RutinasPersonalizadas{ " + "duracionEnSemanas= " + duracionEnSemanas + '}';
    }
}
